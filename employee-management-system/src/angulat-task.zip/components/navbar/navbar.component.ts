import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToasterService } from '../../services/toaster.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavBarComponent {
  constructor(private authService:AuthService,private router:Router,private toaster:ToasterService){}
  islogged:boolean=false;
  onClickLogout(){
    this.toaster.onShowToast("Logout Success",'success');
    this.authService.signOut();
    this.router.navigate(['/login']);
  }
  showLogOut(){
    this.islogged=!this.islogged
  }
}
