import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomValidators } from '../../validators/validators';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToasterService } from '../../services/toaster.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [NgIf,ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  isLogged:boolean=false;
  loginReactiveForm:FormGroup;
  constructor(private authService:AuthService ,private router:Router,private toaster:ToasterService){}
  SwitchMode(){
    this.isLogged=!this.isLogged;
    console.log(this.isLogged)
  }
  ngOnInit(){
    this.loginReactiveForm=new FormGroup({
      username:new FormControl(null,[Validators.required,CustomValidators.noSpaceAllowed]),
      email:new FormControl(null,[Validators.required,Validators.email]),
      password:new FormControl(null,[Validators.required,Validators.minLength(8)])
    })
  }
  onClickLogin(form){
    if(this.isLogged){
      this.authService.signUp(form.value).subscribe({
        next:(res:any)=>{
            form.reset();
            this.isLogged=true;
            this.toaster.onShowToast("Registered Success!!",'success')
        },
        error:(err)=>{
          this.toaster.onShowToast("Register Failed",'error')
        }
      });
    }
    else{
      this.authService.login(form.value).subscribe({
        next:(res:any)=>{
          form.reset();
          this.authService.storeToken(res.token);

          this.toaster.onShowToast(res.message,'success')
          this.router.navigate(['']);
        },
        error:(err)=>{
          console.log(err)
          this.toaster.onShowToast("Login Falied",'error');
        }
      });
    }
  }

}
