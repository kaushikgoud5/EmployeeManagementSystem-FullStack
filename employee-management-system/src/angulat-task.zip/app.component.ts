import { Component, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SideMenuComponent } from './components/side-menu/side-menu.component';
import { NavBarComponent } from './components/navbar/navbar.component';
import { NgClass } from '@angular/common';
import { ToasterComponent } from './components/toaster/toaster.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,SideMenuComponent,NavBarComponent,NgClass,ToasterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'employee-management-system';
  isSideBarHidden:boolean=true;
  isNavHidden(event:boolean){
    this.isSideBarHidden=event;
  }



}

