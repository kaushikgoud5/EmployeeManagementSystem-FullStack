export enum RouteEnum{
    AddEmployee=1,
    ViewEmployee,
    EditEmployee
}
export enum CurrentRouteEnum{
    Employee=1,
    Role
}