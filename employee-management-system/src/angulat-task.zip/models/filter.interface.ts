export interface Filter{
    department: Set<number>,
    status: Set<number>,
    location:Set<number>
    alphabets:Set<string>
      
}