export interface Location {
  locationId: number;
  locationName: string;
  isChecked:boolean;
}
