import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl:string="https://localhost:7098/api/Auth/";
  constructor(private http:HttpClient) { }
  login(loginObj:any){
    console.log(loginObj)
    return this.http.post(`${this.baseUrl}login`,loginObj)
  }
  signUp(userObj:any){
    return this.http.post(`${this.baseUrl}register`,userObj)
  }
  storeToken(tokenValue:string){
    localStorage.setItem("token",tokenValue);
  }
  getToken(){
    return localStorage.getItem("token");
  }
  isLoggedIn():boolean{
    return !!localStorage.getItem("token");
  }
  signOut(){
    localStorage.clear();
  }
}
